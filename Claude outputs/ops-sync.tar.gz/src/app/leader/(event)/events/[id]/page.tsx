import { EventOverviewPage } from '@/features/event/pages/OverviewPage';

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <EventOverviewPage base="/leader" eventId={id} />;
}
